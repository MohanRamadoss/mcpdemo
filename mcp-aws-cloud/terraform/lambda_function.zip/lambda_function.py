import json
import boto3
import os
from datetime import datetime

def lambda_handler(event, context):
    """Simple Lambda function for MCP testing"""
    
    # Get environment info
    environment = os.environ.get('ENVIRONMENT', 'unknown')
    
    # Create response
    response = {
        'statusCode': 200,
        'body': json.dumps({
            'message': 'Hello from AWS Lambda!',
            'environment': environment,
            'timestamp': datetime.utcnow().isoformat(),
            'event': event,
            'function_name': context.function_name if context else 'unknown',
            'aws_request_id': context.aws_request_id if context else 'unknown'
        })
    }
    
    return response
